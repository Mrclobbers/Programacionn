#Pide al usuario dos pares de números x1, y1 y x2, y2, que representen dos puntos en el plano
#Calcula y muestra la distancia entre ellos
numerox1= float(input("Pide el numero x1: "))
numeroy1= float(input("Pide el numero y1: "))
numerox2= float(input("Pide el numero x2: "))
numeroy2= float(input("Pide el numero y2: "))
diferencia_x= abs(numerox1 - numerox2)
diferencia_y= abs(numeroy1 - numeroy2)
print("La diferencia entre los numeros x es de: ", diferencia_x)
print("La diferencia entre los numeros y es de: ", diferencia_y)