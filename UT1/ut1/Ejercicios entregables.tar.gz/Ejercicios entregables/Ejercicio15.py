#Dadas dos variables numéricas A y B, que el usuario debe teclear
#Se pide realizar un algoritmo que intercambie los valores de ambas variables y muestre cuanto valen al final las dos variables
A= float(input("El númer A es: "))
B= float(input("El númer B es: "))
numa_1= A // 10
numa_2= A % 10
numb_1= B // 10
numb_2= B % 10

num_final_A= (numa_2 * 10 + numb_1)
num_final_B= (numb_2 * 10 + numa_1)

print("El número A invertido es: ", num_final_A)
print("El número B invertido es: ", num_final_B)